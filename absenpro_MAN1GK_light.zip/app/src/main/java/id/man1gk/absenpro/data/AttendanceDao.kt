package id.man1gk.absenpro.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AttendanceDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(a: Attendance): Long

    @Query("SELECT * FROM attendance ORDER BY timestamp DESC")
    fun getAll(): Flow<List<Attendance>>

    @Query("DELETE FROM attendance WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM attendance")
    suspend fun clearAll()
}
