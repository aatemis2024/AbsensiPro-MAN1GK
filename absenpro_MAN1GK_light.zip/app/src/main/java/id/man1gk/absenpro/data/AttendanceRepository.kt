package id.man1gk.absenpro.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AttendanceRepository(private val dao: AttendanceDao, private val context: Context) {
    suspend fun add(name: String, nis: String, lat: Double?, lon: Double?) {
        val ts = System.currentTimeMillis()
        dao.insert(Attendance(name = name, nis = nis, timestamp = ts, latitude = lat, longitude = lon, synced = false))
    }
    fun all() = dao.getAll()
    suspend fun deleteById(id: Long) = dao.deleteById(id)
    suspend fun clear() = dao.clearAll()
    suspend fun syncToServer() = withContext(Dispatchers.IO) { /* placeholder */ }
}
