package id.man1gk.absenpro.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun StatsScreen(vm: MainViewModel) {
    Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        Text("Statistik", style = MaterialTheme.typography.h6)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Grafik dan ringkasan hadir akan tampil di sini (placeholder)")
    }
}
