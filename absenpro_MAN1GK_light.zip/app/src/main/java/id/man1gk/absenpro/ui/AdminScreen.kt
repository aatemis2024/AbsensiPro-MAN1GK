package id.man1gk.absenpro.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun AdminScreen(vm: MainViewModel) {
    Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        Text("Admin Panel", style = MaterialTheme.typography.h6)
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = { /* Sign in with Google placeholder */ }) { Text("Sign in with Google (Admin)") }
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = { /* Export CSV */ }) { Text("Export CSV") }
    }
}
