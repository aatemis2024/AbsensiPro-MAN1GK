package id.man1gk.absenpro.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import id.man1gk.absenpro.data.AppDatabase
import id.man1gk.absenpro.data.AttendanceRepository
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

class MainViewModel(application: Application): AndroidViewModel(application) {
    private val repo: AttendanceRepository
    val attendances: StateFlow<List<id.man1gk.absenpro.data.Attendance>>
    init {
        val dao = AppDatabase.getDatabase(application).attendanceDao()
        repo = AttendanceRepository(dao, application.applicationContext)
        attendances = repo.all().map { it }.stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.Lazily, emptyList())
    }
}
