package id.man1gk.absenpro

import java.io.File
import com.github.doyaaaaaken.kotlincsv.client.CsvWriter

fun exportCsvBlocking(filesDir: File, attendances: List<id.man1gk.absenpro.data.Attendance>): File {
    val dir = File(filesDir, "exports")
    if (!dir.exists()) dir.mkdirs()
    val file = File(dir, "attendance_${System.currentTimeMillis()}.csv")
    val writer = CsvWriter().open(file.absolutePath)
    writer.writeRow(listOf("id","name","nis","timestamp","lat","lon","synced"))
    attendances.forEach { a -> writer.writeRow(listOf(a.id.toString(), a.name, a.nis, a.timestamp.toString(), a.latitude?.toString() ?: "", a.longitude?.toString() ?: "", a.synced.toString())) }
    writer.close()
    return file
}
