package id.man1gk.absenpro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import id.man1gk.absenpro.ui.AdminScreen
import id.man1gk.absenpro.ui.HomeScreen
import id.man1gk.absenpro.ui.SettingsScreen
import id.man1gk.absenpro.ui.StatsScreen
import id.man1gk.absenpro.ui.MainViewModel

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val tabs = listOf("Home","Statistik","Admin","Pengaturan")
            var sel by remember { mutableStateOf(0) }
            Scaffold(topBar = { TopAppBar(title={ Text("Absen MAN 1 GK") }, backgroundColor = androidx.compose.ui.graphics.Color(0xFF004D40)) }) {
                Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
                    TabRow(selectedTabIndex = sel) {
                        tabs.forEachIndexed { i, t -> Tab(selected = sel==i, onClick={ sel=i }, text={ Text(t) }) }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    when(sel) {
                        0 -> HomeScreen(vm)
                        1 -> StatsScreen(vm)
                        2 -> AdminScreen(vm)
                        3 -> SettingsScreen(vm)
                    }
                }
            }
        }
    }
}
