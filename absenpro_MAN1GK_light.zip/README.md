Absen MAN 1 GUNUNGKIDUL - Light Premium (Dark-Green theme)
--------------------------------------------------------
This is a lightweight starter Android Studio project (Compose) for Absen MAN1GK.
Features included:
- QR check-in, GPS capture, Room (offline), CSV export
- Admin tab with Google Sign-In scaffolding
- Dark-green theme (elegant)
- No photo upload, no PDF to keep package light

How to build:
1. Open in Android Studio, ensure Kotlin & Compose support.
2. (Optional) Add google-services.json for Firebase features.
3. Build -> Build APK(s) -> locate app-debug.apk in app/build/outputs/apk/debug/

Note: This is a starter template ready to extend. Replace placeholder logos in app/src/main/res/drawable/ when available.
